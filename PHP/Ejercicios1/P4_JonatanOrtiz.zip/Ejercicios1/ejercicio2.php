 <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd"> 
<html>
<head meta charset=utf-8 />
<body>
<?php
	//creo 2 variables y en cada una de ellas almacena un número
	$num1=5;
	$num2=4;
	//muestro la suma de las 2 variables
	print $num1 + $num2
?>
</body>
</html>
