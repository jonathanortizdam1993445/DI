 <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd"> 
<html>
<head meta chrset=utf-8/>
<body>
<?php
	//creo una variable que contiene una cadena de texto 
	$var1="pat";
	//La misma variable continua con la cadena de texto
	$var1.="ata";
	//muestro la cadena detexto completa
	print $var1
	
?>
</body>
</html>
