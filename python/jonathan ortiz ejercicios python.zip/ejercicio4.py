print("Introduce algo")
frase=input();
print(frase.count("a")+frase.count("e")+frase.count("i")+frase.count("o")+frase.count("u"));