def isVowel(char):
	if char == 'a' or char == 'e'  or char =='i' or char =='o' or letra =='u' or char =='A' or char =='E' or char =='I' or char =='O' or char =='U':
			return True
	else:
		return False

print("Indica una letra");

letra =input();

print(isVowel(letra));

	
