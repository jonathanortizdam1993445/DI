#!/usr/bin/env python
print("Dime la frase");
frase=input();

#LE PASAMOS DENTRO DEL METODO COUNT, LA CADENA DE CONTAR 
print(frase.count('bob'));

